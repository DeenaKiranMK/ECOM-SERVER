package com.mtd.ecom_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcomServerApplication.class, args);
	}

}
